import { c as defineEventHandler, r as readBody, e as createError } from '../../_/nitro.mjs';
import { p as prisma$1 } from '../../_/index.mjs';
import jwt from 'jsonwebtoken';
import { Resend } from 'resend';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'node:os';
import 'node:tty';
import 'node:child_process';
import 'node:fs/promises';
import 'node:util';
import 'node:process';
import 'node:async_hooks';
import 'path';
import 'fs';

const prisma = new prisma$1.PrismaClient();
const JWT_SECRET = process.env.JWT_SECRET || "your_secret_key";
const BASE_URL = process.env.BASE_URL || "http://localhost:3000";
const RESEND_API_KEY = process.env.RESEND_API;
const resend = new Resend(RESEND_API_KEY);
const sendResetEmail = async (to, resetUrl, userName) => {
  const currentYear = (/* @__PURE__ */ new Date()).getFullYear();
  const emailHtml = `<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
  <html dir="ltr" lang="en">
    <head>
      <link
        rel="preload"
        as="image"
        href="https://ne-to.com/logo-full.png" />
      <meta content="text/html; charset=UTF-8" http-equiv="Content-Type" />
      <meta name="x-apple-disable-message-reformatting" />
    </head>
    <body style="background-color:#f6f9fc;padding:10px 0">
      <div
        style="display:none;overflow:hidden;line-height:1px;opacity:0;max-height:0;max-width:0">
        \u041D\u0443\u0443\u0446 \u04AF\u0433 \u0441\u044D\u0440\u0433\u044D\u044D\u0445 | NE-TO cargo
        <div>
        </div>
      </div>
      <table
        align="center"
        width="100%"
        border="0"
        cellpadding="0"
        cellspacing="0"
        role="presentation"
        style="max-width:32rem;background-color:#ffffff;border-radius: 16px;padding:32px">
        <tbody>
          <tr style="width:100%">
            <td>
              <img
                alt="ne-to"
                height="32"
                src="https://ne-to.com/logo-full.png"
                style="display:block;outline:none;border:none;text-decoration:none"
                width="123" />
              <table
                align="center"
                width="100%"
                border="0"
                cellpadding="0"
                cellspacing="0"
                role="presentation">
                <tbody>
                  <tr>
                    <td>                    
                    <p
                        style="font-size:16px;line-height:26px;margin:16px 0;font-family:&#x27;Open Sans&#x27;, &#x27;HelveticaNeue-Light&#x27;, &#x27;Helvetica Neue Light&#x27;, &#x27;Helvetica Neue&#x27;, Helvetica, Arial, &#x27;Lucida Grande&#x27;, sans-serif;font-weight:300;color:#404040">
                        \u0421\u0430\u0439\u043D \u0443\u0443, ${userName}
                      </p>
                      <p
                        style="font-size:16px;line-height:26px;margin:16px 0;font-family:&#x27;Open Sans&#x27;, &#x27;HelveticaNeue-Light&#x27;, &#x27;Helvetica Neue Light&#x27;, &#x27;Helvetica Neue&#x27;, Helvetica, Arial, &#x27;Lucida Grande&#x27;, sans-serif;font-weight:300;color:#404040">
                        \u0422\u0430 \u043D\u0443\u0443\u0446 \u04AF\u0433 \u0441\u044D\u0440\u0433\u044D\u044D\u0445 \u0445\u04AF\u0441\u044D\u043B\u0442 \u0438\u043B\u0433\u044D\u044D\u0441\u044D\u043D \u0431\u0430\u0439\u043D\u0430. \u0414\u043E\u043E\u0440\u0445 \u0442\u043E\u0432\u0447 \u0434\u044D\u044D\u0440 \u0434\u0430\u0440\u0436 \u043D\u0443\u0443\u0446 \u04AF\u0433\u044D\u044D \u0441\u044D\u0440\u0433\u044D\u044D\u043D\u044D \u04AF\u04AF:
                      </p>
                      <a
                        href="${resetUrl}"
                        style="line-height:100%;text-decoration:none;display:block;max-width:100%;mso-padding-alt:0px;background-color:#007ee6;border-radius:4px;color:#fff;font-family:&#x27;Open Sans&#x27;, &#x27;Helvetica Neue&#x27;, Arial;font-size:15px;text-align:center;width:210px;padding:14px 7px 14px 7px"
                        target="_blank"
                        ><span
                          style="max-width:100%;display:inline-block;line-height:120%;mso-padding-alt:0px;mso-text-raise:10.5px"
                          >\u041D\u0443\u0443\u0446 \u04AF\u0433 \u0441\u044D\u0440\u0433\u044D\u044D\u0445</span
                        ></a
                      >
                      <p
                        style="font-size:16px;line-height:26px;margin:16px 0;font-family:&#x27;Open Sans&#x27;, &#x27;HelveticaNeue-Light&#x27;, &#x27;Helvetica Neue Light&#x27;, &#x27;Helvetica Neue&#x27;, Helvetica, Arial, &#x27;Lucida Grande&#x27;, sans-serif;font-weight:300;color:#404040">
                        \u0425\u044D\u0440\u044D\u0432 \u0442\u0430 \u044D\u043D\u044D \u0445\u04AF\u0441\u044D\u043B\u0442\u0438\u0439\u0433 \u0438\u043B\u0433\u044D\u044D\u0433\u044D\u044D\u0433\u04AF\u0439 \u0431\u043E\u043B \u0431\u0438\u0434\u044D\u043D\u0434 \u0445\u0430\u043D\u0434\u0430\u043D\u0430 \u0443\u0443.
                      </p>
                      <p
                        style="font-size:16px;line-height:26px;margin:16px 0;font-family:&#x27;Open Sans&#x27;, &#x27;HelveticaNeue-Light&#x27;, &#x27;Helvetica Neue Light&#x27;, &#x27;Helvetica Neue&#x27;, Helvetica, Arial, &#x27;Lucida Grande&#x27;, sans-serif;font-weight:300;color:#404040">
                        \xA9 ${currentYear} NE-TO cargo. \u0411\u04AF\u0445 \u044D\u0440\u0445 \u0445\u0443\u0443\u043B\u0438\u0430\u0440 \u0445\u0430\u043C\u0433\u0430\u0430\u043B\u0430\u0433\u0434\u0441\u0430\u043D.
                      </p>
                    </td>
                  </tr>
                </tbody>
              </table>
            </td>
          </tr>
        </tbody>
      </table>
    </body>
  </html>
  `;
  try {
    const { data, error } = await resend.emails.send({
      from: "NE-TO Security <security@mail.ne-to.com>",
      to: [to],
      subject: "\u041D\u0443\u0443\u0446 \u04AF\u0433 \u0441\u044D\u0440\u0433\u044D\u044D\u0445 | NE-TO cargo",
      html: emailHtml
    });
    console.log(emailHtml);
    if (error) {
      console.error("Error sending reset password email:", error);
      throw new Error("Failed to send reset password email");
    }
    console.log("Reset password email sent successfully:", data);
  } catch (error) {
    console.error("Resend email error:", error);
    throw new Error("Failed to send reset password email");
  }
};
const maskEmail = (email) => {
  if (!email) return "";
  const [username, domain] = email.split("@");
  const maskedUsername = username.charAt(0) + "*".repeat(username.length - 2) + username.charAt(username.length - 1);
  return `${maskedUsername}@${domain}`;
};
const forgotPassword = defineEventHandler(async (event) => {
  try {
    const body = await readBody(event);
    const { phoneNumber } = body;
    if (!phoneNumber) {
      throw createError({
        statusCode: 400,
        message: "Phone number is required"
      });
    }
    const user = await prisma.user.findUnique({
      where: { phoneNumber },
      select: {
        id: true,
        name: true,
        phoneNumber: true,
        email: true
      }
    });
    if (!user) {
      throw createError({
        statusCode: 404,
        message: "\u0411\u04AF\u0440\u0442\u0433\u044D\u043B\u0433\u04AF\u0439 \u0434\u0443\u0433\u0430\u0430\u0440 \u0431\u0430\u0439\u043D\u0430"
      });
    }
    if (!user.email) {
      throw createError({
        statusCode: 400,
        message: "\u0411\u04AF\u0440\u0442\u0433\u044D\u043B\u0442\u044D\u0439 \u0438\u043C\u044D\u0439\u043B \u0445\u0430\u044F\u0433 \u043E\u043B\u0434\u0441\u043E\u043D\u0433\u04AF\u0439"
      });
    }
    const token = jwt.sign(
      { userId: user.id, type: "password-reset" },
      JWT_SECRET,
      { expiresIn: "1h" }
      // Token expires in 1 hour
    );
    const resetUrl = `${BASE_URL}/reset-password/${token}`;
    await sendResetEmail(user.email, resetUrl, user.name);
    return {
      success: true,
      message: "Password reset link has been sent",
      maskedEmail: maskEmail(user.email)
    };
  } catch (error) {
    console.error("Forgot password error:", error);
    throw createError({
      statusCode: error.statusCode || 500,
      message: error.message || "An error occurred while processing your request"
    });
  }
});

export { forgotPassword as default };
//# sourceMappingURL=forgot-password.mjs.map
