import { c as defineEventHandler, r as readBody, e as createError } from '../../_/nitro.mjs';
import { p as prisma$1 } from '../../_/index.mjs';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'node:os';
import 'node:tty';
import 'node:child_process';
import 'node:fs/promises';
import 'node:util';
import 'node:process';
import 'node:async_hooks';
import 'path';
import 'fs';

const prisma = new prisma$1.PrismaClient();
const JWT_SECRET = process.env.JWT_SECRET || "your_secret_key";
const resetPassword = defineEventHandler(async (event) => {
  try {
    const body = await readBody(event);
    const { token, password } = body;
    if (!token || !password) {
      throw createError({
        statusCode: 400,
        message: "Token and password are required"
      });
    }
    try {
      const decoded = jwt.verify(token, JWT_SECRET);
      const userId = decoded.userId;
      const user = await prisma.user.findUnique({
        where: { id: userId }
      });
      if (!user) {
        throw createError({
          statusCode: 404,
          message: "User not found"
        });
      }
      const hashedPassword = await bcrypt.hash(password, 10);
      await prisma.user.update({
        where: { id: userId },
        data: { password: hashedPassword }
      });
      return {
        success: true,
        message: "Password reset successful"
      };
    } catch (err) {
      console.error("Password reset error:", err);
      if (err.name === "TokenExpiredError") {
        throw createError({
          statusCode: 401,
          message: "Token has expired"
        });
      } else if (err.name === "JsonWebTokenError") {
        throw createError({
          statusCode: 401,
          message: "Invalid token"
        });
      } else {
        throw createError({
          statusCode: 401,
          message: "Token verification failed"
        });
      }
    }
  } catch (error) {
    console.error("Reset password error:", error);
    throw createError({
      statusCode: error.statusCode || 500,
      message: error.message || "An error occurred while resetting password"
    });
  }
});

export { resetPassword as default };
//# sourceMappingURL=reset-password.mjs.map
