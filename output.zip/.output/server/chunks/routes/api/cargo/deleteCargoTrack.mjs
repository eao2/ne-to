import { c as defineEventHandler, g as getHeader, f as getQuery } from '../../../_/nitro.mjs';
import { p as prisma$1 } from '../../../_/index.mjs';
import jwt from 'jsonwebtoken';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'node:os';
import 'node:tty';
import 'node:child_process';
import 'node:fs/promises';
import 'node:util';
import 'node:process';
import 'node:async_hooks';
import 'path';
import 'fs';

const prisma = new prisma$1.PrismaClient();
const deleteCargoTrack = defineEventHandler(async (event) => {
  const JWT_SECRET = process.env.JWT_SECRET || "0";
  const authHeader = getHeader(event, "authorization");
  if (!authHeader) {
    return { statusCode: 401, body: { message: "Authorization header missing" } };
  }
  const token = authHeader.split(" ")[1];
  try {
    const query = getQuery(event);
    const id = (query.id || "").trim();
    const decoded = jwt.verify(token, JWT_SECRET);
    if (!decoded || !decoded.userId) {
      return { statusCode: 401, body: { message: "Invalid token" } };
    }
    await prisma.$connect();
    const cargo = await prisma.cargoTracking.delete({
      where: {
        id,
        userId: decoded.userId
      }
    });
    console.log("Cargo deleted:", cargo);
    if (!cargo) {
      return { statusCode: 404, body: { message: "Cargo not found" } };
    }
    return { success: true, data: cargo };
  } catch (error) {
    console.error("Error deleting cargo:", error);
    return { statusCode: 500, message: "\u0410\u0447\u0430\u0430 \u0443\u0441\u0442\u0433\u0430\u0436 \u0447\u0430\u0434\u0441\u0430\u043D\u0433\u04AF\u0439", error: error.message };
  } finally {
    await prisma.$disconnect();
  }
});

export { deleteCargoTrack as default };
//# sourceMappingURL=deleteCargoTrack.mjs.map
