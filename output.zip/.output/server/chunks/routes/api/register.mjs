import { c as defineEventHandler, r as readBody, e as createError } from '../../_/nitro.mjs';
import { p as prisma$1 } from '../../_/index.mjs';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'node:os';
import 'node:tty';
import 'node:child_process';
import 'node:fs/promises';
import 'node:util';
import 'node:process';
import 'node:async_hooks';
import 'path';
import 'fs';

const prisma = new prisma$1.PrismaClient();
const JWT_SECRET = process.env.JWT_SECRET || "your_secret_key";
const register = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const { surName, name, phoneNumber, email, password } = body;
  if (!phoneNumber || !password) {
    throw createError({
      statusCode: 400,
      message: "Phone number and password are required."
    });
  }
  const existingUser = await prisma.user.findUnique({
    where: { phoneNumber }
  });
  const existingUserEmail = await prisma.user.findUnique({
    where: { email }
  });
  if (existingUserEmail) {
    if (existingUserEmail.phoneNumber === phoneNumber) {
      throw createError({
        statusCode: 409,
        message: "\u042D\u043D\u044D \u0445\u044D\u0440\u044D\u0433\u043B\u044D\u0433\u0447 \u0430\u043B\u044C \u0445\u044D\u0434\u0438\u0439\u043D \u0431\u04AF\u0440\u0442\u0433\u044D\u0433\u0434\u0441\u044D\u043D \u0431\u0430\u0439\u043D\u0430."
      });
    } else {
      throw createError({
        statusCode: 409,
        message: "\u042D\u043D\u044D \u0438\u043C\u044D\u0439\u043B \u0445\u0430\u044F\u0433 \u0434\u044D\u044D\u0440 \u0445\u044D\u0440\u044D\u0433\u043B\u044D\u0433\u0447 \u0430\u043B\u044C \u0445\u044D\u0434\u0438\u0439\u043D \u0431\u04AF\u0440\u0442\u0433\u044D\u0433\u0434\u0441\u044D\u043D \u0431\u0430\u0439\u043D\u0430."
      });
    }
  }
  if (existingUser) {
    if (existingUser.userType === "REGISTERED") {
      throw createError({
        statusCode: 409,
        message: "\u042D\u043D\u044D \u0443\u0442\u0430\u0441\u043D\u044B \u0434\u0443\u0433\u0430\u0430\u0440\u0442\u0430\u0439 \u0445\u044D\u0440\u044D\u0433\u043B\u044D\u0433\u0447 \u0430\u043B\u044C \u0445\u044D\u0434\u0438\u0439\u043D \u0431\u04AF\u0440\u0442\u0433\u044D\u0433\u0434\u0441\u044D\u043D \u0431\u0430\u0439\u043D\u0430."
      });
    }
    if (email) {
      const existingEmailUser = await prisma.user.findUnique({
        where: { email }
      });
      if (existingEmailUser && existingEmailUser.phoneNumber !== phoneNumber) {
        throw createError({
          statusCode: 409,
          message: "\u042D\u043D\u044D \u0438\u043C\u044D\u0439\u043B \u0430\u043B\u044C \u0445\u044D\u0434\u0438\u0439\u043D \u04E9\u04E9\u0440 \u0445\u044D\u0440\u044D\u0433\u043B\u044D\u0433\u0447 \u0434\u044D\u044D\u0440 \u0430\u0448\u0438\u0433\u043B\u0430\u0433\u0434\u0430\u0436 \u0431\u0430\u0439\u043D\u0430."
        });
      }
    }
    const hashedPassword2 = await bcrypt.hash(password, 10);
    try {
      const t0 = performance.now();
      const updatedUser = await prisma.user.update({
        where: { phoneNumber },
        data: {
          surName,
          name,
          email: email || existingUser.email,
          // Keep old email if not provided
          password: hashedPassword2,
          userType: "REGISTERED"
        }
      });
      const t1 = performance.now();
      console.log("register update", t1 - t0);
      const token = jwt.sign({
        userId: updatedUser.id,
        phoneNumber: updatedUser.phoneNumber,
        email: updatedUser.email,
        name: updatedUser.name
      }, JWT_SECRET, {
        expiresIn: "30d"
      });
      return {
        token,
        user: {
          id: updatedUser.id,
          surName: updatedUser.surName,
          name: updatedUser.name,
          phoneNumber: updatedUser.phoneNumber,
          email: updatedUser.email,
          userType: updatedUser.userType
        }
      };
    } catch (error) {
      console.error("User update error:", error);
      throw createError({
        statusCode: 500,
        message: "\u0425\u044D\u0440\u044D\u0433\u043B\u044D\u0433\u0447\u0438\u0439\u043D \u043C\u044D\u0434\u044D\u044D\u043B\u043B\u0438\u0439\u0433 \u0448\u0438\u043D\u044D\u0447\u043B\u044D\u0445\u044D\u0434 \u0430\u043B\u0434\u0430\u0430 \u0433\u0430\u0440\u043B\u0430\u0430."
      });
    }
  }
  const hashedPassword = await bcrypt.hash(password, 10);
  try {
    const t0 = performance.now();
    const user = await prisma.user.create({
      data: {
        surName,
        name,
        phoneNumber,
        email,
        password: hashedPassword,
        userType: "REGISTERED"
      }
    });
    const t1 = performance.now();
    console.log("register create", t1 - t0);
    const token = jwt.sign({
      userId: user.id,
      phoneNumber: user.phoneNumber,
      email: user.email,
      name: user.name
    }, JWT_SECRET, {
      expiresIn: "30d"
    });
    return {
      token,
      user: {
        id: user.id,
        surName: user.surName,
        name: user.name,
        phoneNumber: user.phoneNumber,
        email: user.email,
        userType: user.userType
      }
    };
  } catch (error) {
    console.error("Registration error:", error);
    throw createError({
      statusCode: 500,
      message: "\u0425\u044D\u0440\u044D\u0433\u043B\u044D\u0433\u0447\u0438\u0439\u043D \u0431\u04AF\u0440\u0442\u0433\u044D\u043B \u04AF\u04AF\u0441\u0433\u044D\u0445\u044D\u0434 \u0430\u043B\u0434\u0430\u0430 \u0433\u0430\u0440\u043B\u0430\u0430."
    });
  }
});

export { register as default };
//# sourceMappingURL=register.mjs.map
