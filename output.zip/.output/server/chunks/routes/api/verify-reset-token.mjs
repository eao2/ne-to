import { c as defineEventHandler, r as readBody, e as createError } from '../../_/nitro.mjs';
import { p as prisma$1 } from '../../_/index.mjs';
import jwt from 'jsonwebtoken';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'node:os';
import 'node:tty';
import 'node:child_process';
import 'node:fs/promises';
import 'node:util';
import 'node:process';
import 'node:async_hooks';
import 'path';
import 'fs';

const prisma = new prisma$1.PrismaClient();
const JWT_SECRET = process.env.JWT_SECRET || "your_secret_key";
const verifyResetToken = defineEventHandler(async (event) => {
  try {
    const body = await readBody(event);
    const { token } = body;
    if (!token) {
      throw createError({
        statusCode: 400,
        message: "Token is required"
      });
    }
    try {
      const decoded = jwt.verify(token, JWT_SECRET);
      const user = await prisma.user.findUnique({
        where: { id: decoded.userId },
        select: { id: true, phoneNumber: true }
      });
      if (!user) {
        throw createError({
          statusCode: 404,
          message: "User not found"
        });
      }
      return {
        valid: true,
        user: {
          id: user.id,
          phoneNumber: user.phoneNumber
        }
      };
    } catch (err) {
      console.error("Token verification error:", err);
      if (err.name === "TokenExpiredError") {
        throw createError({
          statusCode: 401,
          message: "Token has expired"
        });
      } else if (err.name === "JsonWebTokenError") {
        throw createError({
          statusCode: 401,
          message: "Invalid token"
        });
      } else {
        throw createError({
          statusCode: 401,
          message: "Token verification failed"
        });
      }
    }
  } catch (error) {
    console.error("Verify reset token error:", error);
    throw createError({
      statusCode: error.statusCode || 500,
      message: error.message || "An error occurred while verifying token"
    });
  }
});

export { verifyResetToken as default };
//# sourceMappingURL=verify-reset-token.mjs.map
