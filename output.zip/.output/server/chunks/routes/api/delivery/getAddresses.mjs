import { c as defineEventHandler, g as getHeader } from '../../../_/nitro.mjs';
import { p as prisma$1 } from '../../../_/index.mjs';
import jwt from 'jsonwebtoken';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'node:os';
import 'node:tty';
import 'node:child_process';
import 'node:fs/promises';
import 'node:util';
import 'node:process';
import 'node:async_hooks';
import 'path';
import 'fs';

const prisma = new prisma$1.PrismaClient();
const getAddresses = defineEventHandler(async (event) => {
  const JWT_SECRET = process.env.JWT_SECRET || "0";
  const authHeader = getHeader(event, "authorization");
  if (!authHeader) {
    return { statusCode: 401, message: "Authorization header missing" };
  }
  const token = authHeader.split(" ")[1];
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    if (!(decoded == null ? void 0 : decoded.userId)) {
      return { statusCode: 401, message: "Invalid token" };
    }
    await prisma.$connect();
    const addresses = await prisma.deliveryAddress.findMany({
      where: {
        userId: decoded.userId
      },
      include: {
        defaultForUser: true
      },
      orderBy: {
        createdAt: "desc"
      }
    });
    return {
      success: true,
      data: addresses.map((addr) => ({
        ...addr,
        isDefault: !!addr.defaultForUser
      }))
    };
  } catch (error) {
    console.error("Error fetching addresses:", error);
    return { success: false, message: "Failed to fetch addresses" };
  } finally {
    await prisma.$disconnect();
  }
});

export { getAddresses as default };
//# sourceMappingURL=getAddresses.mjs.map
