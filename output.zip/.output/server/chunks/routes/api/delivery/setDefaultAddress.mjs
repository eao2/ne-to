import { c as defineEventHandler, g as getHeader, r as readBody } from '../../../_/nitro.mjs';
import { p as prisma$1 } from '../../../_/index.mjs';
import jwt from 'jsonwebtoken';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'node:os';
import 'node:tty';
import 'node:child_process';
import 'node:fs/promises';
import 'node:util';
import 'node:process';
import 'node:async_hooks';
import 'path';
import 'fs';

const prisma = new prisma$1.PrismaClient();
const setDefaultAddress = defineEventHandler(async (event) => {
  const JWT_SECRET = process.env.JWT_SECRET || "0";
  const authHeader = getHeader(event, "authorization");
  if (!authHeader) {
    return { statusCode: 401, message: "Authorization header missing" };
  }
  const token = authHeader.split(" ")[1];
  try {
    const body = await readBody(event);
    const decoded = jwt.verify(token, JWT_SECRET);
    if (!(decoded == null ? void 0 : decoded.userId)) {
      return { statusCode: 401, message: "Invalid token" };
    }
    if (!body.addressId) {
      return { statusCode: 400, message: "Address ID is required" };
    }
    await prisma.$connect();
    const address = await prisma.deliveryAddress.findFirst({
      where: {
        id: body.addressId,
        userId: decoded.userId
      }
    });
    if (!address) {
      return { statusCode: 404, message: "Address not found" };
    }
    await prisma.user.update({
      where: { id: decoded.userId },
      data: { defaultDeliveryAddressId: body.addressId }
    });
    return {
      success: true,
      message: "\u04AE\u043D\u0434\u0441\u044D\u043D \u0445\u0430\u044F\u0433 \u0430\u043C\u0436\u0438\u043B\u0442\u0442\u0430\u0439 \u04E9\u04E9\u0440\u0447\u043B\u04E9\u0433\u0434\u043B\u04E9\u04E9"
    };
  } catch (error) {
    console.error("Error setting default address:", error);
    return { success: false, message: "Failed to set default address" };
  } finally {
    await prisma.$disconnect();
  }
});

export { setDefaultAddress as default };
//# sourceMappingURL=setDefaultAddress.mjs.map
