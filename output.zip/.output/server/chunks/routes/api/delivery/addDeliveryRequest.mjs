import { c as defineEventHandler, g as getHeader, r as readBody } from '../../../_/nitro.mjs';
import { p as prisma$1 } from '../../../_/index.mjs';
import jwt from 'jsonwebtoken';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'node:os';
import 'node:tty';
import 'node:child_process';
import 'node:fs/promises';
import 'node:util';
import 'node:process';
import 'node:async_hooks';
import 'path';
import 'fs';

const prisma = new prisma$1.PrismaClient();
const addDeliveryRequest = defineEventHandler(async (event) => {
  var _a;
  const JWT_SECRET = process.env.JWT_SECRET || "0";
  const authHeader = getHeader(event, "authorization");
  if (!authHeader) {
    return { statusCode: 401, message: "Authorization header missing" };
  }
  const token = authHeader.split(" ")[1];
  try {
    const body = await readBody(event);
    const decoded = jwt.verify(token, JWT_SECRET);
    if (!(decoded == null ? void 0 : decoded.userId)) {
      return { statusCode: 401, message: "Invalid token" };
    }
    if (!((_a = body.cargoIds) == null ? void 0 : _a.length) || !body.deliveryAddressId) {
      return { statusCode: 400, message: "Missing required fields" };
    }
    await prisma.$connect();
    const deliveryRequests = await Promise.all(body.cargoIds.map(
      (cargoId) => prisma.deliveryRequest.create({
        data: {
          cargoId,
          requestedByUserId: decoded.userId,
          deliveryAddressId: body.deliveryAddressId,
          status: "PENDING"
        }
      })
    ));
    return {
      success: true,
      data: deliveryRequests,
      message: "\u0425\u04AF\u0440\u0433\u044D\u043B\u0442\u0438\u0439\u043D \u0437\u0430\u0445\u0438\u0430\u043B\u0433\u0430 \u0430\u043C\u0436\u0438\u043B\u0442\u0442\u0430\u0439 \u0431\u04AF\u0440\u0442\u0433\u044D\u0433\u0434\u043B\u044D\u044D"
    };
  } catch (error) {
    console.error("Error creating delivery request:", error);
    return {
      success: false,
      message: "Failed to create delivery request",
      error: error.message
    };
  } finally {
    await prisma.$disconnect();
  }
});

export { addDeliveryRequest as default };
//# sourceMappingURL=addDeliveryRequest.mjs.map
