import { c as defineEventHandler, g as getHeader, r as readBody, e as createError } from '../../_/nitro.mjs';
import { p as prisma$1 } from '../../_/index.mjs';
import jwt from 'jsonwebtoken';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'node:os';
import 'node:tty';
import 'node:child_process';
import 'node:fs/promises';
import 'node:util';
import 'node:process';
import 'node:async_hooks';
import 'path';
import 'fs';

const prisma = new prisma$1.PrismaClient();
const createCargo = defineEventHandler(async (event) => {
  const JWT_SECRET = process.env.JWT_SECRET || "0";
  const authHeader = getHeader(event, "authorization");
  if (!authHeader) {
    return { statusCode: 401, body: { message: "Authorization header missing" } };
  }
  const token = authHeader.split(" ")[1];
  try {
    const body = await readBody(event);
    const decoded = jwt.verify(token, JWT_SECRET);
    if (!decoded || !decoded.userId) {
      return { statusCode: 401, body: { message: "Invalid token" } };
    }
    if (!body.trackingNumber) {
      throw createError({ statusCode: 400, message: "Tracking number is required." });
    }
    console.log("\u{1F50D} Checking cargo tracking entry...");
    await prisma.$connect();
    const checkExist = await prisma.cargoTracking.findUnique({
      where: {
        trackingNumber: body.trackingNumber.trim()
      }
    });
    if (checkExist && (checkExist.currentStatus === "RECEIVED_AT_ERENHOT" || checkExist.currentStatus === "IN_TRANSIT") && !checkExist.userId) {
      const updatedCargo = await prisma.cargoTracking.update({
        where: {
          trackingNumber: body.trackingNumber.trim()
        },
        data: {
          userId: decoded.userId,
          nickname: body.nickname || null
        }
      });
      console.log("\u2705 Cargo claimed and updated:", updatedCargo);
      return { success: true, data: updatedCargo, message: "\u0410\u0447\u0430\u0430 \u0430\u043C\u0436\u0438\u043B\u0442\u0442\u0430\u0439 \u0445\u043E\u043B\u0431\u043E\u0433\u0434\u043B\u043E\u043E" };
    }
    if (checkExist) {
      if (checkExist.userId) {
        return { statusCode: 406, body: { message: "\u0410\u043B\u044C \u0445\u044D\u0434\u0438\u0439\u043D \u0431\u04AF\u0440\u0442\u0433\u044D\u0433\u0434\u0441\u044D\u043D \u0431\u0430\u0439\u043D\u0430" } };
      } else {
        return { statusCode: 406, body: { message: "\u042D\u043D\u044D \u0430\u0447\u0430\u0430 \u043E\u0434\u043E\u043E\u0433\u043E\u043E\u0440 \u0431\u04AF\u0440\u0442\u0433\u044D\u0445 \u0431\u043E\u043B\u043E\u043C\u0436\u0433\u04AF\u0439 \u0431\u0430\u0439\u043D\u0430" } };
      }
    }
    const newCargo = await prisma.cargoTracking.create({
      data: {
        trackingNumber: body.trackingNumber.trim(),
        nickname: body.nickname ? body.nickname : null,
        cargoType: body.cargoType || "NORMAL",
        price: null,
        paymentStatus: "PENDING",
        preRegisteredDate: /* @__PURE__ */ new Date(),
        currentStatus: "PRE_REGISTERED",
        userId: decoded.userId
      }
    });
    console.log("\u2705 New cargo created:", newCargo);
    return { success: true, data: newCargo, message: "\u0428\u0438\u043D\u044D \u0430\u0447\u0430\u0430 \u0430\u043C\u0436\u0438\u043B\u0442\u0442\u0430\u0439 \u0431\u04AF\u0440\u0442\u0433\u044D\u0433\u0434\u043B\u044D\u044D" };
  } catch (error) {
    console.error("\u274C Error processing cargo:", error);
    return { statusCode: 500, message: "Failed to process cargo", error: error.message };
  } finally {
    await prisma.$disconnect();
  }
});

export { createCargo as default };
//# sourceMappingURL=createCargo.mjs.map
