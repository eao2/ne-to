import { c as defineEventHandler, g as getHeader, r as readBody } from '../../_/nitro.mjs';
import { p as prisma$1 } from '../../_/index.mjs';
import jwt from 'jsonwebtoken';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'node:os';
import 'node:tty';
import 'node:child_process';
import 'node:fs/promises';
import 'node:util';
import 'node:process';
import 'node:async_hooks';
import 'path';
import 'fs';

const prisma = new prisma$1.PrismaClient();
const isValidEmail = (email) => {
  const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
  return emailRegex.test(email);
};
const isValidPhoneNumber = (phone) => {
  const phoneRegex = /^[0-9]{8}$/;
  return phoneRegex.test(phone);
};
const index = defineEventHandler(async (event) => {
  const JWT_SECRET = process.env.JWT_SECRET || "0";
  const authHeader = getHeader(event, "authorization");
  if (!authHeader) {
    return { statusCode: 401, message: "Authorization header missing" };
  }
  const token = authHeader.split(" ")[1];
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    if (!(decoded == null ? void 0 : decoded.userId)) {
      return { statusCode: 401, message: "Invalid token" };
    }
    await prisma.$connect();
    if (event.method === "GET") {
      const user = await prisma.user.findUnique({
        where: { id: decoded.userId },
        include: {
          defaultDeliveryAddress: true
        }
      });
      if (!user) {
        return { statusCode: 404, message: "User not found" };
      }
      return {
        success: true,
        data: user
      };
    }
    if (event.method === "PATCH") {
      const body = await readBody(event);
      const { field, value } = body;
      if (!field) {
        return { statusCode: 400, message: "Field is required" };
      }
      const allowedFields = ["name", "phoneNumber", "email", "autoDeliveryRequest"];
      if (!allowedFields.includes(field)) {
        return { statusCode: 400, message: "Invalid field" };
      }
      if (field === "autoDeliveryRequest" && value === true) {
        const user = await prisma.user.findUnique({
          where: { id: decoded.userId },
          include: { defaultDeliveryAddress: true }
        });
        if (!user.defaultDeliveryAddress) {
          return {
            statusCode: 400,
            message: "\u04AE\u043D\u0434\u0441\u044D\u043D \u0445\u0430\u044F\u0433\u0430\u0430 \u0441\u043E\u043D\u0433\u043E\u0441\u043D\u044B \u0434\u0430\u0440\u0430\u0430 \u0445\u04AF\u0440\u0433\u044D\u043B\u0442\u0438\u0439\u0433 \u0438\u0434\u044D\u0432\u0445\u0436\u04AF\u04AF\u043B\u044D\u0445 \u0431\u043E\u043B\u043E\u043C\u0436\u0442\u043E\u0439"
          };
        }
      }
      if (field === "email" && value) {
        if (!isValidEmail(value)) {
          return {
            statusCode: 400,
            message: "\u0418-\u043C\u044D\u0439\u043B \u0445\u0430\u044F\u0433 \u0431\u0443\u0440\u0443\u0443 \u0431\u0430\u0439\u043D\u0430"
          };
        }
      }
      if (field === "phoneNumber") {
        if (!isValidPhoneNumber(value)) {
          return {
            statusCode: 400,
            message: "\u0423\u0442\u0430\u0441\u043D\u044B \u0434\u0443\u0433\u0430\u0430\u0440 8 \u043E\u0440\u043E\u043D\u0442\u043E\u0439 \u0442\u043E\u043E \u0431\u0430\u0439\u0445 \u0451\u0441\u0442\u043E\u0439"
          };
        }
      }
      if (field === "phoneNumber" || field === "email") {
        const existing = await prisma.user.findFirst({
          where: {
            [field]: value,
            NOT: { id: decoded.userId }
          }
        });
        if (existing) {
          return {
            statusCode: 400,
            message: field === "phoneNumber" ? "\u042D\u043D\u044D \u0443\u0442\u0430\u0441\u043D\u044B \u0434\u0443\u0433\u0430\u0430\u0440 \u0431\u04AF\u0440\u0442\u0433\u044D\u043B\u0442\u044D\u0439 \u0431\u0430\u0439\u043D\u0430" : "\u042D\u043D\u044D \u0438-\u043C\u044D\u0439\u043B \u0445\u0430\u044F\u0433 \u0431\u04AF\u0440\u0442\u0433\u044D\u043B\u0442\u044D\u0439 \u0431\u0430\u0439\u043D\u0430"
          };
        }
      }
      const updatedUser = await prisma.user.update({
        where: { id: decoded.userId },
        data: { [field]: value }
      });
      return {
        success: true,
        data: updatedUser
      };
    }
    return { statusCode: 405, message: "Method not allowed" };
  } catch (error) {
    console.error("Account API error:", error);
    return { statusCode: 500, message: "Internal server error" };
  } finally {
    await prisma.$disconnect();
  }
});

export { index as default };
//# sourceMappingURL=index.mjs.map
