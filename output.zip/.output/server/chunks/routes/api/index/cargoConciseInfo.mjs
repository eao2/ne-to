import { c as defineEventHandler, g as getHeader } from '../../../_/nitro.mjs';
import { p as prisma$1 } from '../../../_/index.mjs';
import jwt from 'jsonwebtoken';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'node:os';
import 'node:tty';
import 'node:child_process';
import 'node:fs/promises';
import 'node:util';
import 'node:process';
import 'node:async_hooks';
import 'path';
import 'fs';

const prisma = new prisma$1.PrismaClient();
const STATUS_PRIORITY = {
  "DELIVERED_TO_UB": 4,
  "IN_TRANSIT": 3,
  "RECEIVED_AT_ERENHOT": 2,
  "PRE_REGISTERED": 1
};
const cargoConciseInfo = defineEventHandler(async (event) => {
  const JWT_SECRET = process.env.JWT_SECRET || "0";
  const authHeader = getHeader(event, "authorization");
  if (!authHeader) {
    return { success: true, data: null, user: false };
  }
  const token = authHeader.split(" ")[1];
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    if (!decoded || !decoded.userId) {
      return { success: true, data: null, user: false };
    }
    await prisma.$connect();
    const cargos = await prisma.cargoTracking.groupBy({
      by: ["currentStatus"],
      where: {
        userId: decoded.userId,
        currentStatus: {
          in: ["DELIVERED_TO_UB", "IN_TRANSIT", "RECEIVED_AT_ERENHOT", "PRE_REGISTERED"]
        }
      },
      _count: {
        currentStatus: true
      }
    });
    if (cargos.length === 0) {
      return { success: true, data: null, user: true };
    }
    const statusWithCounts = cargos.map((c) => ({
      status: c.currentStatus,
      count: c._count.currentStatus,
      priority: STATUS_PRIORITY[c.currentStatus]
    }));
    const highestPriorityStatus = statusWithCounts.reduce((prev, current) => {
      return current.priority > prev.priority ? current : prev;
    });
    return {
      success: true,
      data: {
        status: highestPriorityStatus.status,
        count: highestPriorityStatus.count
      },
      user: true
    };
  } catch (error) {
    console.error("Error fetching cargo concise info:", error);
    return { success: true, data: null, user: false };
  } finally {
    await prisma.$disconnect();
  }
});

export { cargoConciseInfo as default };
//# sourceMappingURL=cargoConciseInfo.mjs.map
