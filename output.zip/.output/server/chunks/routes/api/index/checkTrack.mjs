import { c as defineEventHandler, f as getQuery, e as createError } from '../../../_/nitro.mjs';
import { p as prisma$1 } from '../../../_/index.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'jsonwebtoken';
import 'node:os';
import 'node:tty';
import 'node:child_process';
import 'node:fs/promises';
import 'node:util';
import 'node:process';
import 'node:async_hooks';
import 'path';
import 'fs';

const prisma = new prisma$1.PrismaClient();
const checkTrack = defineEventHandler(async (event) => {
  try {
    const query = getQuery(event);
    const { trackingNumber } = query;
    if (!trackingNumber) {
      throw createError({
        statusCode: 400,
        message: "Tracking number is required."
      });
    }
    await prisma.$connect();
    const cargo = await prisma.cargoTracking.findUnique({
      where: { trackingNumber },
      include: {
        destinationLocation: true
      }
    });
    if (!cargo) {
      throw createError({
        statusCode: 404,
        message: "\u0422\u0440\u0430\u043A \u043A\u043E\u0434 \u043E\u043B\u0434\u0441\u043E\u043D\u0433\u04AF\u0439."
      });
    }
    console.log(cargo);
    return { success: true, data: cargo };
  } catch (error) {
    console.error("Error fetching cargo tracking:", error.message, error.stack);
    throw createError({
      statusCode: 404,
      message: "\u0422\u0440\u0430\u043A \u043A\u043E\u0434 \u043E\u043B\u0434\u0441\u043E\u043D\u0433\u04AF\u0439."
    });
  } finally {
    await prisma.$disconnect();
  }
});

export { checkTrack as default };
//# sourceMappingURL=checkTrack.mjs.map
