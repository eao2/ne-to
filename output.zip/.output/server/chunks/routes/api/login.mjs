import { c as defineEventHandler, r as readBody, e as createError } from '../../_/nitro.mjs';
import { p as prisma$1 } from '../../_/index.mjs';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'node:os';
import 'node:tty';
import 'node:child_process';
import 'node:fs/promises';
import 'node:util';
import 'node:process';
import 'node:async_hooks';
import 'path';
import 'fs';

const prisma = new prisma$1.PrismaClient();
const JWT_SECRET = process.env.JWT_SECRET || "your_secret_key";
const login = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const { phoneNumber, password } = body;
  if (!phoneNumber || !password) {
    throw createError({ statusCode: 400, message: "Phone number and password are required." });
  }
  const user = await prisma.user.findUnique({
    where: { phoneNumber }
  });
  if (!user || !user.password) {
    throw createError({ statusCode: 401, message: "Invalid credentials." });
  }
  const isValid = await bcrypt.compare(password, user.password);
  if (!isValid) {
    throw createError({ statusCode: 401, message: "Invalid credentials." });
  }
  const token = jwt.sign({ userId: user.id, userName: user.username, email: user.email }, JWT_SECRET, { expiresIn: "30d" });
  return { token, user };
});

export { JWT_SECRET, login as default };
//# sourceMappingURL=login.mjs.map
