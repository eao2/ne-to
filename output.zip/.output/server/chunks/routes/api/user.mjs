import { c as defineEventHandler, g as getHeader, h as sendRedirect } from '../../_/nitro.mjs';
import { p as prisma$1 } from '../../_/index.mjs';
import jwt from 'jsonwebtoken';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'node:os';
import 'node:tty';
import 'node:child_process';
import 'node:fs/promises';
import 'node:util';
import 'node:process';
import 'node:async_hooks';
import 'path';
import 'fs';

const prisma = new prisma$1.PrismaClient();
const user = defineEventHandler(async (event) => {
  const JWT_SECRET = process.env.JWT_SECRET || "0";
  const authHeader = getHeader(event, "authorization");
  if (!authHeader) {
    return { statusCode: 401, body: { message: "Authorization header missing" } };
  }
  const token = authHeader.split(" ")[1];
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    if (!decoded || !decoded.userId) {
      return sendRedirect(event, "/login", 302);
    }
    const t0 = performance.now();
    const user = await prisma.user.findUnique({
      where: { id: decoded.userId },
      select: {
        id: true,
        name: true,
        phoneNumber: true,
        email: true,
        emailVerified: true,
        userType: true
      }
    });
    const t1 = performance.now();
    console.log("user data", t1 - t0);
    if (!user) {
      return { statusCode: 404, body: { message: "User not found" } };
    }
    return { statusCode: 200, body: user };
  } catch (err) {
    console.error("Error verifying token or fetching user:", err);
    return { statusCode: 401, body: { message: "Unauthorized access" } };
  } finally {
    await prisma.$disconnect();
  }
});

export { user as default };
//# sourceMappingURL=user.mjs.map
