import{M as s}from"./DkP_XJbs.js";const t=s("/logo-main.svg");export{t as _};
