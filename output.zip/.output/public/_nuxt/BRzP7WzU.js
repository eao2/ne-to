import{M as s}from"./DkP_XJbs.js";const r=s("/svg/bar-code.svg");export{r as _};
